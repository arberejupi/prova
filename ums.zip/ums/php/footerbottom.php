		
</div>
<footer class="container">
	<h3 style="text-align:center;background:#2A2B3C;margin:0;padding:15px;color:#fff;font-weight:normal">&copy;Developed by Md Abul Kalam - <?php echo date("Y");?> </h3>
</footer>
</html>